"""
Instrucciones para agregar el logo
=====================================

El logo debe guardarse como: src/assets/logo_cait.png

Pasos:
1. Descarga o guarda la imagen del logo CAIT Panamá
2. Cópialo a la carpeta: src/assets/
3. Asegúrate de que se llame exactamente: logo_cait.png
4. Reinicia la aplicación

El logo aparecerá automáticamente en la parte superior del header.
Se usará como marca de agua opaca en los PDFs generados.

Formato recomendado:
- Formato: PNG con fondo transparente
- Tamaño: Mínimo 200x200 píxeles
- La aplicación lo redimensionará a 100x100 píxeles en el header
"""
